# Natural Language Toolkit: Language Models
#
# Copyright (C) 2001-2012 NLTK Project
# Author: Steven Bird <sb@csse.unimelb.edu.au>
# URL: <http://www.nltk.org/>
# For license information, see LICENSE.TXT

from .ngram import NgramModel
from .LgramModel import LgramModel

